#!/usr/bin/env python3

from socket import AF_INET, socket, SOCK_STREAM
from threading import Thread
import tkinter
import sys
connected = False

def Receive():

	while True:
		try:
			msg = client_socket.recv(BUFSIZ).decode("utf8")
			msg_list.insert(tkinter.END, msg + '\n')
			msg_list.see("end")
		except OSError:  # Possibly client has left the chat.
			break


def send(event=None):  # Event is passed by binders.

	msg = my_msg.get()
	my_msg.set("")  # Clears input field.

	client_socket.send(bytes(msg, "utf8"))

	if msg == "quit":
		client_socket.close()
		window.quit()
		sys.exit


def On_Closing(event=None):

	my_msg.set("quit")
	send()


window = tkinter.Tk()
window.title("CharMU")
window.configure(bg="#262830")

main_frame = tkinter.Frame(window, bg="#262830")

entry_frame = tkinter.Frame(main_frame, bg="#262830")
msg_frame = tkinter.Frame(main_frame, bg="#262830")

my_msg = tkinter.StringVar()
my_msg.set("")

msg_list = tkinter.Text( msg_frame,
height=30, width=90, bd=0,
font=('Courier', 12),
bg="#141618", fg="light gray", insertbackground="light gray")

entry_field = tkinter.Entry( entry_frame,
font=('Courier', 12), bd=0,
bg="#141618", fg="light gray", insertbackground="light gray",
textvariable=my_msg)

entry_field.bind("<Return>", send)

msg_list.pack(fill=tkinter.BOTH)
entry_field.pack(fill=tkinter.X)

msg_frame.pack(side=tkinter.TOP, pady=4)
entry_frame.pack(side=tkinter.BOTTOM, fill=tkinter.X, pady=4)

main_frame.pack(padx=12, pady=8)

window.protocol("WM_DELETE_WINDOW", On_Closing)

#SOCKETS STUFF BELOW#
HOST = input('Enter host: ')

if not HOST:
	HOST = "127.0.0.1"

PORT = 25565
BUFSIZ = 2048

ADDR = (HOST, PORT)

client_socket = socket(AF_INET, SOCK_STREAM)
client_socket.connect(ADDR)
connected = True

Receive_thread = Thread(target=Receive)
Receive_thread.start()
tkinter.mainloop()  # Starts GUI execution.
