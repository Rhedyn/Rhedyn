class Thing(object):
	ALLTHINGS = {}

	def __init__(self, uid = len(ALLTHINGS)):
		Thing.ALLTHINGS[int(uid)] = self
		self.uid = int(uid)
