#!/usr/bin/env python3

from socket import AF_INET, socket, SOCK_STREAM
from threading import Thread
from datetime import datetime
from user import User

def Accept_Incoming_Connections():

	while True:
		client, client_address = SERVER.accept()
		print(f"{client_address} has connected.")
		client.send(bytes("Please provide your username and password separated by a space.", "utf8"))
		addresses[client] = client_address
		Thread(target=Handle_Client, args=(client,)).start()


def Handle_Client(client):
	while True:
		try:
			name, password = client.recv(BUFSIZ).decode("utf8").split(' ')
			for uid in User.ALLTHINGS:
				if User.ALLTHINGS[uid].username == name and User.ALLTHINGS[uid].password == password:
					client.send(bytes( f"Welcome {name}. Your uID is {uid}.", "utf8"))
					client.send(bytes("-"*80, "utf8"))
					msg = f"[SERVER]\n{name} has joined the chat."
					Broadcast(bytes(msg, "utf8"))
					clients[client] = uid
					break
		except:
			try:
				client.send(bytes( f"Details invalid.", "utf8"))
				continue
			except:
				client.close()
		break

	while True:
		try:
			msg = client.recv(BUFSIZ)
		except:
			client.close()
			del clients[client]
			break
		d_msg_arr = msg.decode("utf-8").split(" ")

		if len(d_msg_arr) > 0:
			if d_msg_arr[0] == "!username":
				new_name = " ".join(d_msg_arr[1:])
				if len(new_name) > 15:
					name = new_name[:12] + "..."
					client.send(bytes(f"[PRIVATE]\nUsername too long to display, please shorten to see in full.\n", "utf8"))
					
				else:
					client.send(bytes(f"[PRIVATE]\nSet [{name}]'s username to [{new_name}].\n","utf-8"))
					name = new_name

			elif msg != bytes("quit", "utf8"):
				Broadcast(msg, f"[{name}]\n")

			else:
				client.send(bytes("quit", "utf8"))
				client.close()
				del clients[client]
				Broadcast(bytes(f"[SERVER]\n{name} has left the chat.", "utf8"))
				break


def Broadcast(msg, prefix=""):  # prefix is for name identification.

	now = datetime.now()
	current_time = now.strftime("%H:%M:%S")
	current_date = now.strftime("%d-%m-%Y")
	message = msg.decode("utf-8")

	for sock in clients:
		sock.send(bytes(f"{current_time} {prefix}{message}\n", "utf8"))

	with open(f'logs\\log_{current_date}.txt','a+') as log:
		log.write(f"{current_time} {prefix}{message}\n")

def Load_Users():
	with open("data\\users.txt", 'r+') as utext:
		for uinfo in utext.read().split("\n</user>\n"):
			current_uinfo = uinfo.split('\n')
			User(current_uinfo[0], current_uinfo[1], current_uinfo[2], current_uinfo[3].split(','))

Load_Users()

clients = {}
addresses = {}

HOST = ''
PORT = 25565
BUFSIZ = 2048
ADDR = (HOST, PORT)

SERVER = socket(AF_INET, SOCK_STREAM)
SERVER.bind(ADDR)

if __name__ == "__main__":
	SERVER.listen(5)
	print("Waiting for connection...")
	ACCEPT_THREAD = Thread(target=Accept_Incoming_Connections)
	ACCEPT_THREAD.start()
	ACCEPT_THREAD.join()
	SERVER.close()
