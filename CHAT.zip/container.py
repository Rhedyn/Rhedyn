class Container(object):
	def __init__(self):
		self.contents = {}

	def Add_UID(self, uid):
		if uid in self.contents.keys():
			self.contents[uid] += 1
		else:
			self.contents[uid] = 1

	def Add_UIDs(self, uids):
		for uid in uids:
			self.Add_UID(uid)

	def Take_UID(self, uid):
		if uid in self.contents.keys():
			if self.contents[uid] > 1:
				self.contents[uid] -=1
				return uid
			else:
				del self.contents[uid]
				return uid
		return None

	def Get_As_Text(self):
		r = ""
		for i in self.contents:
			r += f"{i}(){self.contents[i]})\n"
		return r
