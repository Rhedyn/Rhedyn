from thing import Thing
from container import Container
class User(Thing):
	def __init__(self, uid, username, password, inventory_uids):
		super().__init__(uid)
		self.username = username
		self.password = password
		self.inventory = Container()
		self.inventory.Add_UIDs(inventory_uids)

	def Print_Info(self):
		print(self.uid, self.username)
